#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include "Sonic.h"
#define FPS 60
#define WIDTH 1024
#define HEIGHT 768
#define SPEED 5
using namespace std;

bool g_running = false;
Uint32 g_start, g_end, g_delta, g_fps;
const Uint8* g_keystates;
SDL_Window* g_pWindow;
SDL_Renderer* g_pRenderer;
SDL_Texture* g_pSonicHorzTexture;
SDL_Rect g_player; // For primitive rectangle.
SDL_Rect g_src, g_dst; // For the ship sprite.
SDL_Rect g_space = { 0,0,1024,768 };
bool g_fire = false; // Fire toggle.
bool g_turret = false; // Another fire toggle for turret.
SDL_Point g_mousePos;
Sonic g_sonic(512, 384);

// Init function. Sets up SDL and all subsystems and other (dynamic) memory allocation.
int Init(const char* title, int xPos, int yPos, int width, int height, int flags)
{
	cout << "Initializing game..." << endl;
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0) // If initialization is okay.
	{
		// Try to create the SDL_Window.
		g_pWindow = SDL_CreateWindow(title, xPos, yPos, width, height, flags);
		if (g_pWindow != nullptr) // If window creation passes.
		{
			// Try to create the SDL_Renderer. (Back buffer)
			g_pRenderer = SDL_CreateRenderer(g_pWindow, -1, 0);
			if (g_pRenderer != nullptr)
			{
				if (IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG) != 0)
				{
					g_pSonicHorzTexture = IMG_LoadTexture(g_pRenderer, "Sonic_horz.png");
				}
				else return false; // Image init failed.
			}
			else return false; // Renderer creation failed.
		}
		else return false; // Window creation failed.
	}
	else return false; // Initialization has failed.
	// If everything is okay, we are here...
	g_fps = (Uint32)round(1 / (double)FPS * 1000);
	g_keystates = SDL_GetKeyboardState(nullptr);
	g_player = { WIDTH/2, HEIGHT/2, 35, 55 };

	g_src = { 0, 0, 154, 221 }; // Clips out entire image.
	g_dst = { WIDTH / 2, HEIGHT / 2, 154, 221 }; // On screen location/appearance.

	cout << "Initialization successful!" << endl;
	g_running = true;
	return true;
}

// HandleEvents function. Gets input from user, e.g. mouse/keyboard/gamepad events.
void HandleEvents()
{
	//cout << "Getting input..." << endl;
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT: // Pressing 'X' button of window.
			g_running = false;
			break;
		}
	}
}

bool KeyDown(SDL_Scancode c)
{
	if (g_keystates != nullptr)
	{
		if (g_keystates[c] == 1) // Key we're testing for is down.
			return true;
	}
	return false;
}

// Update function. Moves objects, performs physics, e.g. projectiles, gravity, collisions.
void Update()
{
	//cout << "Updating game..." << endl;
	// Determine enemy animation state.
	switch (g_sonic.m_state)
	{
	case IDLE:
		// Transition to move animation.
		if (KeyDown(SDL_SCANCODE_W) || KeyDown(SDL_SCANCODE_D) || KeyDown(SDL_SCANCODE_S) || KeyDown(SDL_SCANCODE_A))
		{
			g_sonic.SetAnimation(MOVE, 0, 9);
		}
		break;

		if (KeyDown(SDL_SCANCODE_W) || KeyDown(SDL_SCANCODE_S) || KeyDown(SDL_SCANCODE_D) || KeyDown(SDL_SCANCODE_A))
		{
			g_sonic.SetAnimation(MOVE, 10, 18);
		}
		break;
	case MOVE: 
		// Transition to idle animation.
		if (!KeyDown(SDL_SCANCODE_W) && !KeyDown(SDL_SCANCODE_D) && !KeyDown(SDL_SCANCODE_S) && !KeyDown(SDL_SCANCODE_A))
		{
			g_sonic.SetAnimation(IDLE, 8, 9);
		}
		break;

		if (!KeyDown(SDL_SCANCODE_W) && !KeyDown(SDL_SCANCODE_S) && !KeyDown(SDL_SCANCODE_A) && !KeyDown(SDL_SCANCODE_D))
		{
			g_sonic.SetAnimation(IDLE, 17, 18);
		}
		break;
	}

	if (KeyDown(SDL_SCANCODE_A) && g_sonic.m_dst.x >= 0)
		g_sonic.m_dst.x -= SPEED;
	if (KeyDown(SDL_SCANCODE_D) && g_sonic.m_dst.x >= 0)
		g_sonic.m_dst.x += SPEED;

	if (KeyDown(SDL_SCANCODE_S) && g_sonic.m_dst.y < HEIGHT - g_sonic.m_dst.h)
		g_sonic.m_dst.y += SPEED;
	if (KeyDown(SDL_SCANCODE_W) && g_sonic.m_dst.y > 0)
		g_sonic.m_dst.y -= SPEED;
	g_sonic.Update();
}

// Render function. Renders changes in game objects to window.
void Render()
{
	//cout << "Rendering changes to window..." << endl;
	SDL_SetRenderDrawColor(g_pRenderer, 0, 0, 0, 255);
	SDL_RenderClear(g_pRenderer);
	SDL_RenderCopy(g_pRenderer, g_pSonicHorzTexture, &g_sonic.m_src, &g_sonic.m_dst); 
	SDL_RenderPresent(g_pRenderer); // Flip buffers - send data to window.
}

// Clean function. De-initialize SDL and de-allocate memory.
void Clean()
{
	cout << "Cleaning up..." << endl;
	SDL_DestroyRenderer(g_pRenderer);
	SDL_DestroyWindow(g_pWindow);
	SDL_DestroyTexture(g_pSonicHorzTexture);
	IMG_Quit();
	SDL_Quit();
}

void Wake()
{
	g_start = SDL_GetTicks(); // Gets milliseconds since SDL initialization.
}

void Sleep()
{
	g_end = SDL_GetTicks();
	g_delta = g_end - g_start; // 1055 - 1050 = 5ms
	if (g_delta < g_fps) // if (5ms < 17ms)
		SDL_Delay(g_fps - g_delta); // Engine sleeps for 12ms.
}

// Run function. Contains the primary game loop.
int Run()
{
	if (g_running == true) // If engine is already running.
	{
		return 1;
	}
	if (Init("GAME1007_LE4_MahadeoDevin", SDL_WINDOWPOS_CENTERED,
		SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT, 0) == false) // If initialization failed.
	{
		return 2; 
	}
	// If initialization passes, we are here.
	while (g_running) // Primary game loop. "frame"
	{
		Wake();
		HandleEvents(); // Input.
		Update(); // Processing.
		Render(); // Output.
		if (g_running == true)
			Sleep();
	}
	Clean();
	return 0;
}

// main function. Entry point in every C++ program.
int main(int argc, char* argv[])
{
	return Run();
}

