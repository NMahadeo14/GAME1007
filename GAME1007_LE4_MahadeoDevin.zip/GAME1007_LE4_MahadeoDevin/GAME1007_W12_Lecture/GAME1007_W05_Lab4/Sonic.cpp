#include <SDL.h>
#include "Sonic.h"

Sonic::Sonic(int x, int y) :m_src( {0,0,128,128} ),m_frameCtr(0), m_frameMax(3),
	m_spriteIdx(0), m_spriteMin(8), m_spriteMax(9), m_state(IDLE) // Initializers happen before body.
{ // Body considered assignment not initialization.
	m_dst = {x,y,m_src.w,m_src.h};
	m_spriteIdx = m_spriteMin;
}

void Sonic::Update()
{
	// Animate.
	if (m_frameCtr++ == m_frameMax)
	{
		m_frameCtr = 0;
		if (++m_spriteIdx == m_spriteMax)
		{
			m_spriteIdx = m_spriteMin;
		}
		m_src.x = 0 + m_src.w * m_spriteIdx;
	}
	// Move.
	
}

void Sonic::SetAnimation(state s, unsigned short min, unsigned short max)
{
	m_state = s;
	m_spriteIdx = m_spriteMin = min;
	m_spriteMax = max;
	m_frameCtr = 0;
}
