#include <iostream>
#include <SDL.h>
#define FPS 60
#define WIDTH 1024
#define HEIGHT 768
using namespace std;

bool g_running = false;
Uint32 g_start, g_end, g_delta, g_fps;
const Uint8* g_ketstates;
SDL_Window* g_pWindow;
SDL_Renderer* g_pRenderer;


//Init function. Sets up SDL and all subsystems and other (dynamic) memory allocation
int Init(const char* title, int xPos, int yPos, int width, int height, int flags)
{
	cout << "Initalizing Game..." << endl;
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0) // If initialization is okay
	{
		// Try to create the SDL window
		g_pWindow = SDL_CreateWindow(title, xPos, yPos, width, height, flags);
		if (g_pWindow != nullptr) // If window creation passes
		{
			// Try to create the SDL_Renderer. (Back Buffer)
			g_pRenderer = SDL_CreateRenderer(g_pWindow, -1, 0);
			if (g_pRenderer != nullptr)
			{
				//Do stuff later
			}
			else return false; // Renderer creation has failed
		}
		else return false; // Window creation has failed
	}
	else return false; // Initialization has failed.

	// if everything is ok we are here...

	g_fps = (Uint32)round(1 / (double)FPS) * 1000;
	g_ketstates = SDL_GetKeyboardState(nullptr);
	cout << "Initialization Sucessful!" << endl;
	g_running = true;
	return true;
}

// Clean function, De-initalization SDL and de-allocate memory.
void Clean()
{
	cout << "Cleaning up..." << endl;
	SDL_DestroyRenderer(g_pRenderer);
	SDL_DestroyWindow(g_pWindow);
	SDL_Quit();
}

//HandleEvents function. Gets input from user, E.g. mouse/keyboard/gamepad events
void HandleEvents()
{
	cout << "Getting Input..." << endl;
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT: // Pressing 'X' button of window
			g_running = false;
			break;
		}
	}
}

bool KeyDown(SDL_Scancode c)
{
	if (g_ketstates != nullptr)
	{
		if (g_ketstates[c] == 1)
		{
			return true;
		}
	}
	return false;
}

//Update function. Moves objects, performs physics, e.g. projectiles, gravity, collisions
void Update()
{
	cout << "Updating game..." << endl;
	if (KeyDown(SDL_SCANCODE_F))
	{
		cout << "F key pressed!" << endl;
	}
}

//Render function. Renders changes in game objects window
void Render()
{
	cout << "Rendering changes to window..." << endl;
	SDL_SetRenderDrawColor(g_pRenderer, 0, 128, 128, 255);
	SDL_RenderClear(g_pRenderer);
	//Any drawing goes here...

	SDL_RenderPresent(g_pRenderer);
}


void Wake()
{
	g_start = SDL_GetTicks(); // Gets milliseconds since SDL initialization
}

void Sleep()
{
	g_end = SDL_GetTicks();
	g_delta = g_end - g_start; //1055 - 1050 = 5ms

	if (g_delta < g_fps) // if(5ms < 17ms)
	{
		SDL_Delay(g_fps - g_delta); // Engine sleeps for 12ms
	}
}


//Run function. Contains the primary game loop;
int Run()
{
	if (g_running == true) // if engine is already running
	{
		return 1;
	}
	
	if (Init("GAME1007_M1_MahadeoDevin", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT, 0) == false) // if initialization failed
	{
		return 2;
	}

	//if initialization passes, we are here
	while (g_running) // Primary game loop. "Frame"
	{
		Wake();
		HandleEvents();//Input
		Update();//Processing
		Render();//Output
		if (g_running == true)
		{
			Sleep();
		}
	}
	Clean();
	return 0;
}

int main(int argc, char* argv[])
{


	return Run();
}