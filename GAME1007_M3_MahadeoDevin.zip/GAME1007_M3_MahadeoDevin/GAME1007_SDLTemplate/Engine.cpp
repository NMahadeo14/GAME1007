#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include "Engine.h"

using namespace std;

int Engine::Init(const char* title, int xPos, int yPos, int width, int height, int flags)
{
	cout << "Initializing engine..." << endl;
	srand((unsigned)time(NULL)); // Seed Random number Sequence
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0) // If initialization is okay...
	{
		// Create the SDL window...
		cout << "First pass." << endl;
		m_pWindow = SDL_CreateWindow(title, xPos, yPos, width, height, flags);
		if (m_pWindow != nullptr)
		{
			// Create the SDL renderer...(back buffer)
			cout << "Second pass." << endl;
			m_pRenderer = SDL_CreateRenderer(m_pWindow, -1, NULL);
			if (m_pRenderer != nullptr)
			{
				// Initialize subsystems later...
				cout << "Third pass." << endl;

				if (IMG_Init(IMG_INIT_PNG || IMG_INIT_JPG) != 0)
				{
					m_pShipTexture = IMG_LoadTexture(m_pRenderer, "Ship.png");
					m_pBGTexture = IMG_LoadTexture(m_pRenderer, "Background.png");
					m_pMissileTexture = IMG_LoadTexture(m_pRenderer, "missile.png");
					m_pEnemyTexture = IMG_LoadTexture(m_pRenderer, "Enemy.png");
					m_pEnemyMissileTexture = IMG_LoadTexture(m_pRenderer, "EnemyMissile.png");
					if (m_pShipTexture == nullptr)
					{
						return false; // image load failed.
					}
				}
				else return false; // Image init failed

				/*if (Mix_Init(MIX_INIT_MP3) != 0)
				{
					Mix_OpenAudio(22050, AUDIO_S16SYS, 2, 4096);
					Mix_AllocateChannels(16);

					m_pboom = Mix_LoadWAV("aud/laserShoot.wav");
					m_pfire = Mix_LoadWAV("aud/explosion.wav");

					m_pOC = Mix_LoadMUS("aud/Orbital Colossus.mp3");
				}*/
			}
			else return false; // Renderer creation failed.
		}
		else return false; // Window creation failed.
	}
	else return false; // initalization failed.
	m_fps = (Uint32)round(1.0 / (double)FPS * 1000); // Converts FPS into milliseconds, e.g. 16.67
	m_keystates = SDL_GetKeyboardState(nullptr);
	m_player = { WIDTH / 2, HEIGHT / 2, 150, 250};
	//Define source and destination rectangles
	m_src = { 0, 0, 154, 221};
	m_dst = { WIDTH / 2, HEIGHT / 2, 154, 221};
	//Define rectangles for the background
	m_bg1 = { 0, 0, 1024, 768 };
	m_bg2 = { 1024, 0, 1024, 768 };

	//Enemy
	m_enemySource = { 0,0,76,71};

	//Missles
	m_missile.reserve(4); // Preallocation of 4 elements of the vector array;
	m_eMissile.reserve(4);

	//Mix_PlayMusic(m_pOC, -5);
	//Mix_VolumeMusic(32);
	cout << "Initialization successful!" << endl;
	m_running = true;
	return true;
}

void Engine::Clean()
{
	cout << "Cleaning engine..." << endl;
	//Clean up Vector.
	for (unsigned i = 0; i < m_missile.size(); i++)
	{
		delete m_missile[i]; // Deallocates Missile through pointer
		m_missile[i] = nullptr; // Ensures the Pointer is free
	}

	for (unsigned i = 0; i < m_enemies.size(); i++)
	{
		delete m_enemies[i]; // deallocate SDL_Rect
		m_enemies[i] = nullptr;
	}

	for (unsigned i = 0; i < m_eMissile.size(); i++)
	{
		delete m_eMissile[i];
		m_eMissile[i] = nullptr;
	}

	m_enemies.clear();
	m_enemies.shrink_to_fit();
	m_missile.clear(); // removes all elements. Size = 0;
	m_missile.shrink_to_fit(); // sets capacity to size
	m_eMissile.clear();
	m_eMissile.shrink_to_fit();
	SDL_DestroyRenderer(m_pRenderer);
	SDL_DestroyWindow(m_pWindow);
	SDL_DestroyTexture(m_pShipTexture);
	SDL_DestroyTexture(m_pBGTexture);
	SDL_DestroyTexture(m_pMissileTexture);
	SDL_DestroyTexture(m_pEnemyTexture);
	SDL_DestroyTexture(m_pEnemyMissileTexture);
	
	/*Mix_FreeChunk(m_pfire);
	Mix_FreeChunk(m_pboom);
	Mix_FreeMusic(m_pOC);
	Mix_CloseAudio();
	Mix_Quit();*/
	IMG_Quit();
	SDL_Quit();
}

void Engine::Wake()
{
	m_start = SDL_GetTicks();
}

void Engine::HandleEvents()
{
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT:
			m_running = false;
			break;
		case SDL_KEYUP:
			if (event.key.keysym.sym == 13)
			{
				//Fire dynamic Missile.
				m_missile.push_back(new Missile(m_dst.x + m_dst.w / 2 + 20, m_dst.y + m_dst.h / 2 - 50));
				m_missile.shrink_to_fit();

				//Mix_PlayChannel(-2, m_pfire, 0);
			}
		}
	}
}

void Engine::Update()
{
	//cout << "Updating game..." << endl;
	if (KeyDown(SDL_SCANCODE_S) && m_dst.y < HEIGHT - m_dst.h)
		m_dst.y += SPEED;
	if (KeyDown(SDL_SCANCODE_W) && m_dst.y > 0)
		m_dst.y -= SPEED;

	if (KeyDown(SDL_SCANCODE_A) && m_dst.x > 0)
		m_dst.x -= SPEED;
	if (KeyDown(SDL_SCANCODE_D) && m_dst.x < (WIDTH / 2))
		m_dst.x += SPEED;

	//scroll backgrounds
	m_bg1.x -= SPEED;
	m_bg2.x -= SPEED;
	// Check if we need to bounce backgrounds back to original positions
	if (m_bg1.x <= -m_bg1.w)
	{
		m_bg1.x = 0;
		m_bg2.x = 1024;
	}

	//Move and animate missles
	for (unsigned i = 0; i < m_missile.size(); i++)
	{
		m_missile[i]->Update();
		//m_missile.at(i)->Update();
	}

	for (unsigned i = 0; i < m_eMissile.size(); i++)
	{
		m_eMissile[i]->Update();
	}

	// Deallocate missiles that go off-screen
	for (unsigned i = 0; i < m_eMissile.size(); i++)
	{
		if (m_eMissile[i]->m_dst.x < 0)
		{
			delete m_eMissile[i]; // Deallocates missile through pointer
			m_eMissile[i] = nullptr; // makes sure the pointer is completely empty
			m_eMissile.erase(m_eMissile.begin() + i); // erase element and resize the array;
			m_eMissile.shrink_to_fit();
			//Options:
			break;
			//or i--;
		}
	}

	// Deallocate missiles that go off-screen
	for (unsigned i = 0; i < m_missile.size(); i++)
	{
		if (m_missile[i]->m_dst.x > 1024)
		{
			delete m_missile[i]; // Deallocates missile through pointer
			m_missile[i] = nullptr; // makes sure the pointer is completely empty
			m_missile.erase(m_missile.begin() + i); // erase element and resize the array;
			m_missile.shrink_to_fit();
			//Options:
			break;
			//or i--;
		}
	}

	for (unsigned i = 0; i < m_eMissile.size(); i++)
	{
		if (m_eMissile[i]->m_dst.x < 0)
		{
			delete m_eMissile[i]; // Deallocates missile through pointer
			m_eMissile[i] = nullptr; // makes sure the pointer is completely empty
			m_eMissile.erase(m_eMissile.begin() + i); // erase element and resize the array;
			m_eMissile.shrink_to_fit();
			//Options:
			break;
			//or i--;
		}
	}
	//Print vector capacity and size
	cout << "cap: " << m_missile.capacity() << " sz: " << m_missile.size() << endl;

	//spawn enemies

	if (m_spawnCtr++ == m_spawnMax)
	{
		m_spawnCtr = 0;
		m_enemies.push_back(new SDL_Rect({ 1044 ,rand() % 680,76,71}));
		for (unsigned i = 0; i < m_enemies.size(); i++)
		{
			m_eMissile.push_back(new EMissile(m_enemies[i]->x + m_enemies[i]->w / 3, m_enemies[i]->y + m_enemies[i]->h - 50));
		}
		cout << "Spawning" << endl;
	}

	for (unsigned i = 0; i < m_enemies.size(); i++)
	{
		m_enemies[i]->x -= SPEED;
	}

	// Collision check of all missiles vs enemy.
	for (unsigned i = 0; i < m_missile.size(); i++)
	{
		for (unsigned j = 0; j < m_enemies.size(); j++)
		{
			Mix_PlayChannel(-1, m_pboom, 0);
			if (SDL_HasIntersection(&m_missile[i]->m_dst, m_enemies[j]))
			{
				cout << "Enemy hit by missile #" << i << "!" << endl;
				//Destroy missile
				delete m_enemies[j];
				delete m_missile[i];
				m_enemies[j] = nullptr;
				m_missile[i] = nullptr;
				m_missile.erase(m_missile.begin() + i);
				m_enemies.erase(m_enemies.begin() + j);
				m_enemies.shrink_to_fit();
				m_missile.shrink_to_fit();
				//lower the tint of the enemy.
				return;
			}
		}
		
	}
	

}

void Engine::Render()
{
	SDL_SetRenderDrawColor(m_pRenderer, 0, 0, 0, 255);
	SDL_RenderClear(m_pRenderer);
	// Any drawing here...

	SDL_RenderCopy(m_pRenderer, m_pBGTexture, NULL, &m_bg1); // for BG
	SDL_RenderCopy(m_pRenderer, m_pBGTexture, NULL, &m_bg2); // for BG
	SDL_RenderCopyEx(m_pRenderer, m_pShipTexture, NULL, &m_dst, 90.0, NULL, SDL_FLIP_NONE); // for ship

	//Render Missles
	for (unsigned i = 0; i < m_missile.size(); i++)
	{
		SDL_RenderCopy(m_pRenderer, m_pMissileTexture, &m_missile[i]->m_src, &m_missile[i]->m_dst); // for missles
	}

	//Render Missles
	for (unsigned i = 0; i < m_eMissile.size(); i++)
	{
		SDL_RenderCopy(m_pRenderer, m_pEnemyMissileTexture, &m_eMissile[i]->m_src, &m_eMissile[i]->m_dst); // for missles
	}

	//Iterate and render enemies

	for (unsigned i = 0; i < m_enemies.size(); i++)
	{
		SDL_RenderCopy(m_pRenderer, m_pEnemyTexture, &m_enemySource, m_enemies[i]);
	}

	SDL_RenderPresent(m_pRenderer); // Flip buffers - send data to window.
}

void Engine::Sleep()
{
	m_end = SDL_GetTicks();
	m_delta = m_end - m_start; // 1055 - 1050 = 5ms
	if (m_delta < m_fps)
		SDL_Delay(m_fps - m_delta);
}

bool Engine::KeyDown(SDL_Scancode c)
{
	if (m_keystates != nullptr)
	{
		if (m_keystates[c] == 1)
		{
			return true;
		}
	}
	return false;
}

int Engine::Run()
{
	if (m_running == true)
	{
		return 1;
	}
	// Start and run the "engine"
	if (Init("GAME1007 M3", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT, NULL) == false)
	{
		return 2;
	}
	// We passed our initial checks, start the loop!
	while (m_running == true)
	{
		Wake();
		HandleEvents(); // Input
		Update();       // Processing
		Render();       // Output
		if (m_running == true)
			Sleep();
	}
	Clean();
	return 0;
}
