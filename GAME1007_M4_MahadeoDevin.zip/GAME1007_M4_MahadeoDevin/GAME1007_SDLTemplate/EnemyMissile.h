#ifndef _ENEMYMISSILE_H
#define _ENEMYMISSILE_H
#include <SDL.h>
#include <vector>
#define EMOVESPEED 10

class EMissile
{
private:
	unsigned short m_frameCtr; // Counts the number of frames
	unsigned short m_frameMax; // Number of frames each sprite is displayed, Animation speed
	unsigned short m_spriteIdx; // Which sprite to display.
	unsigned short m_spriteMax; // Number of sprites in the animation;
public:
	SDL_Rect m_src;
	SDL_Rect m_dst;

	EMissile(int x = 0, int y = 0); // Default and non-Default constructor
	void Update();
};
#endif // !_ENEMYMISSILE_H

