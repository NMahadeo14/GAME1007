#ifndef _ENGINE_H_
#define _ENGINE_H_
#include <SDL.h>
#include <SDL_mixer.h>
#include <vector>
#include <iostream>
#include <ctime>
#include "Missile.h"
#include "EnemyMissile.h"
#define FPS 60
#define WIDTH 1024
#define HEIGHT 768
#define SPEED 12
#define ENEMYMS 7
using namespace std;

class Engine
{
private: // private properties

	bool m_running = false;
	Uint32 m_start, m_end, m_delta, m_fps;
	const Uint8* m_keystates;
	SDL_Window* m_pWindow;
	SDL_Renderer* m_pRenderer;
	SDL_Texture* m_pShipTexture; // Every source image needs a SDL_Texture
	SDL_Texture* m_pBGTexture;// For Background

	SDL_Rect m_player;
	SDL_Rect m_src, m_dst; // For the ship sprite

	//Two Destination rectangles for bg.
	SDL_Rect m_bg1;
	SDL_Rect m_bg2;

	//for Enemy
	SDL_Texture* m_pEnemyTexture;
	//Vector for the missile pointer
	SDL_Texture* m_pMissileTexture;
	vector<Missile*> m_missile;
	//Enemy Spawn timer
	SDL_Rect m_enemySource;
	vector<SDL_Rect*> m_enemies;

	SDL_Texture* m_pEnemyMissileTexture;
	vector<EMissile*> m_eMissile;
	int m_spawnCtr = 0;
	int m_spawnMax = 90; // 180 frames = 3 seconds

	Mix_Chunk* m_pfire;
	Mix_Chunk* m_pboom;

	Mix_Chunk* m_pefire;
	Mix_Music* m_pOC;


private: // private method prototypes
	int Init(const char* title, int xPos, int yPos, int width, int height, int flags);
	void Clean();
	void Wake();
	void HandleEvents();
	void Update();
	void Render();
	void Sleep();
	bool KeyDown(SDL_Scancode c);
public: // Public method protypes
	int Run();

};
#endif

