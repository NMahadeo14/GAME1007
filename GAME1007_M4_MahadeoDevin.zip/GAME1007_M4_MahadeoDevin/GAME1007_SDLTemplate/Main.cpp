/*******************************************************************************
* File Name   :		 
* Description :	
* Author      :	
* Created     :	
* Modified    :	
*******************************************************************************/

// SDL includes pasted for convenience. Move/copy to relevant files.
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mixer.h>
#include <SDL_ttf.h>
#include <vector>
#include "Engine.h"
#include "Missile.h"

int main(int argc, char* argv[])
{
	Engine game;
	return game.Run();
}