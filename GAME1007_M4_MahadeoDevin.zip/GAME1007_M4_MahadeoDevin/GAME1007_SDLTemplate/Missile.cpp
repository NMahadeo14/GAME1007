#include "Engine.h"
#include "Missile.h"

Missile::Missile(int x, int y) : m_src({ 0,573,108,164 }), m_frameCtr(0), m_frameMax(5), m_spriteIdx(0), m_spriteMax(5)
{
	m_dst = { x, y, m_src.w / 2, m_src.h / 2};

}

void Missile::Update()
{
	//Animate
	if (m_frameCtr++ == m_frameMax)
	{
		m_frameCtr = 0;

		if (++m_spriteIdx == m_spriteMax)
		{
			m_spriteIdx = 0;
		}

		/*if (m_spriteIdx == 0)
		{
			m_src.x = 0 + m_src.w;
		}

		if (m_spriteIdx == 1)
		{
			m_src.x = 108 + 177 + m_src.w;
		}
		
		if (m_spriteIdx == 2)
		{
			m_src.x = 285 + 258 + m_src.w;
		}

		if (m_spriteIdx == 4)
		{
			m_src.x = 543 + 378 + m_src.w;
		}*/
	}


	//Move
	m_dst.x += MOVESPEED;
}
